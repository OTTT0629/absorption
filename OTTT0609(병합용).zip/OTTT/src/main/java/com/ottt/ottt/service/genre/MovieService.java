package com.ottt.ottt.service.genre;

import java.util.List;

import com.ottt.ottt.dto.ContentDTO;


public interface MovieService {

	List<ContentDTO> getMovie()throws Exception;
}
