package com.ottt.ottt.dao.genre;

import java.util.List;

import com.ottt.ottt.dto.ContentDTO;

public interface DramaDao {

	List<ContentDTO> dramaSelect() throws Exception;
}
