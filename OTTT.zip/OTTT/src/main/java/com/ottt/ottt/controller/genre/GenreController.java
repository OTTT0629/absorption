package com.ottt.ottt.controller.genre;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ottt.ottt.dto.ContentDTO;
import com.ottt.ottt.service.genre.AnimationService;
import com.ottt.ottt.service.genre.DramaService;
import com.ottt.ottt.service.genre.InterestService;
import com.ottt.ottt.service.genre.MovieService;

@Controller
@RequestMapping("/genre")
public class GenreController {

	@Autowired
	MovieService movieService;
	
	@Autowired
	InterestService interestService;
	
	@Autowired
	DramaService dramaService;
	
	@Autowired
	AnimationService animationService;
	
	@GetMapping("/movie")
	public String movie(Model m, HttpServletRequest request) {
		try {
			List<ContentDTO> list = movieService.getMovie();
			m.addAttribute("list", list);
		} catch (Exception e) {e.printStackTrace();}
		
		return "/genre/movie";
	}
	
	@GetMapping("/interest")
	public String interest(Model m, HttpServletRequest request) {
		try {
			List<ContentDTO> list = interestService.getInterest();
			m.addAttribute("list", list);
		} catch (Exception e) {e.printStackTrace();}
		
		return "/genre/interest";
	}
	
	@GetMapping("/drama")
	public String drama(Model m, HttpServletRequest request) {
		try {
			List<ContentDTO> list = dramaService.getDrama();
			m.addAttribute("list", list);
		} catch (Exception e) {e.printStackTrace();}
		
		return "/genre/drama";
	}
	
	@GetMapping("/animation")
	public String animation(Model m, HttpServletRequest request) {
		try {
			List<ContentDTO> list = animationService.getAnimation();
			m.addAttribute("list", list);
		} catch (Exception e) {e.printStackTrace();}
		
		return "/genre/animation";
	}
	
//	@GetMapping("/index")
//	public String index() {
//		return "/genre/index";
//	}
}
