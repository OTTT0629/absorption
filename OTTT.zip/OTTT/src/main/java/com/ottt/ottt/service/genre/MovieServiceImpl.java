package com.ottt.ottt.service.genre;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ottt.ottt.dao.genre.MovieDao;
import com.ottt.ottt.dto.ContentDTO;


@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieDao movieDao;
	
	@Override
	public List<ContentDTO> getMovie() throws Exception {
		// TODO Auto-generated method stub
		return movieDao.movieSelect();
	}
	
	
}
