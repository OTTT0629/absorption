package com.ottt.ottt.dao.genre;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ottt.ottt.dto.ContentDTO;

@Repository
public class InterestDaoImpl implements InterestDao{
	
	@Autowired
	private SqlSession session;
	private static String namespace ="com.ottt.ottt.dao.genre.interestMapper.";

	@Override
	public List<ContentDTO> interestSelect() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+"interestSelect");
	}
	
	
}
